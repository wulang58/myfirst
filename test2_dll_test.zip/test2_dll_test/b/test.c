#include <stdio.h>
#include "add.h"
// 定义ADD函数，实现两个整数的加法
// int ADD(int a, int b) {
//     return a + b;
// }




int main() {
    int num1, num2, result;
   
     printf("请输入两个整数，用空格分隔: ");
    // 提示用户输入两个数字
    
    scanf("%d %d", &num1, &num2);
    
    // 调用ADD函数进行加法运算
    result = ADD(num1, num2);
    
    // 输出结果
    printf("%d + %d = %d\n", num1, num2, result);
    
    return 0;
}
