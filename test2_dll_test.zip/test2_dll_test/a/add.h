#ifndef ADD_H
#define ADD_H
int ADD(int a, int b);
#endif  