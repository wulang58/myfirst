#include "add.h"

int ADD(int a, int b) {
    return a + b;
}